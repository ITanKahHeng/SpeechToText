module.exports = require("./data/corejs2-built-ins.json");
