'use strict'
Object.defineProperty(exports, '__esModule', { value: true })

const legacy = require('../dist/legacy-exports')
exports.binary = legacy.binary
exports.default = [exports.binary]

legacy.warnFileDeprecation(__filename)
